Below are the ways to run the project:
---- 